using System.Windows.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace VatLoverzy
{
    public partial class Form1 : Form
    {
        // quiz game variables
        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;
        public Form1()
        {
            InitializeComponent();
            askQuestion(questionNumber);
            totalQuestions = 8;
        }
        private void checkAnswerEvent(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;
            int buttonTag = Convert.ToInt32(senderObject.Tag);
            if (buttonTag == correctAnswer)
            {
                score++;
            }
            if (questionNumber == totalQuestions)
            {
                // work out the percentage
                percentage = (int)Math.Round((double)(score * 100) / totalQuestions);
                MessageBox.Show(
                "Quiz Ended!" + Environment.NewLine +
                "You have answered " + score + " questions correctly." + Environment.NewLine +
                "Your total percentage is " + percentage + "%" + Environment.NewLine +
                "Click OK to play again"
                );
                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);
            }
            questionNumber++;
            askQuestion(questionNumber);
        }
        private void askQuestion(int qnum)
        {
            switch (qnum)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.pexels_trace_constant_707046;
                    lblQuestion.Text = "Jaka to marka pojazdu?";
                    button1.Text = "BMW";
                    button2.Text = "Toyota";
                    button3.Text = "Honda";
                    button4.Text = "Kamaz";
                    correctAnswer = 1;
                    break;
                case 2:
                    pictureBox1.Image = Properties.Resources.aston;
                    lblQuestion.Text = "Jaka to marka pojazdu?";
                    button1.Text = "Bawara";
                    button2.Text = "Aston Martin";
                    button3.Text = "Audi";
                    button4.Text = "Pagani";
                    correctAnswer = 2;
                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.audi;
                    lblQuestion.Text = "Jaka to marka pojazdu?";
                    button1.Text = "Ferrari ";
                    button2.Text = "Lamborghini";
                    button3.Text = "Maserati ";
                    button4.Text = "Audi";
                    correctAnswer = 4;
                    break;
                case 4:
                    pictureBox1.Image = Properties.Resources.lambo;
                    lblQuestion.Text = "Jaka to marka pojazdu?";
                    button1.Text = "Lada";
                    button2.Text = "MAzda";
                    button3.Text = "Lamborghini";
                    button4.Text = "Syrenka";
                    correctAnswer = 3;
                    break;
                case 5:
                    pictureBox1.Image = Properties.Resources.pexels_mike_b_193991;
                    lblQuestion.Text = "Jaka to marka pojazdu?";
                    button1.Text = "lambo";
                    button2.Text = "lada";
                    button3.Text = "Kamaz";
                    button4.Text = "Mercedes Benz";
                    correctAnswer = 4;
                    break;
                case 6:
                    pictureBox1.Image = Properties.Resources.pexels_garvin_st_villier_3972750;
                    lblQuestion.Text = "Jaka to marka pojazdu?";
                    button1.Text = "Dacia";
                    button2.Text = "Audi";
                    button3.Text = "PIEKNY NAJLEPSZY LEXUS";
                    button4.Text = "Fiat";
                    correctAnswer = 3;
                    break;
                case 7:
                    pictureBox1.Image = Properties.Resources.pexels_kamshotthat_8438891;
                    lblQuestion.Text = "Jaka to marka pojazdu?";
                    button1.Text = "Bmw";
                    button2.Text = "Toyota";
                    button3.Text = "Honda";
                    button4.Text = "Mazda";
                    correctAnswer = 3;
                    break;
                case 8:
                    pictureBox1.Image = Properties.Resources.ferrari__1_;
                    lblQuestion.Text = "Jaka to marka pojazdu?";
                    button1.Text = "Ferara";
                    button2.Text = "Lambo";
                    button3.Text = "Fiat";
                    button4.Text = "FSO";
                    correctAnswer = 1;
                    break;
            }
        }

        private void lblQuestion_Click(object sender, EventArgs e)
        {

        }
    }
}